// LSP Prblm.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

using namespace std;


#include <list>

class Paragraph;
class HyperLink;
class Header;

class IDocumentConverter
{
public:
	virtual void Convert(Paragraph* para) = 0;
	virtual void Convert(HyperLink* hyper) = 0;
	virtual void Convert(Header* header) = 0;
	/*virtual void ConvertParagraph(Paragraph& para) = 0;
	virtual void ConvertHyperLink(HyperLink& hyper) = 0;
	virtual void ConvertHeader(Header& header) = 0;*/
};

class DocumentPart
{
public:
	virtual void Print() = 0;
	virtual void Save() = 0;
	virtual void Convert(IDocumentConverter *coverter) = 0;
	virtual void ConvertDoc() = 0;
};

class Paragraph : public DocumentPart
{
public:
	void Print()
	{
		std::cout << "Paragraph Print" << endl;
	}
	void Save()
	{
		std::cout << "Paragraph Save" << endl;
	}
	void Convert(IDocumentConverter *coverter)
	{
		std::cout << "Paragaraph Converter" << endl;
		if (nullptr != coverter)
			coverter->Convert(this);
	}
	void ConvertDoc()
	{
		std::cout << "Paragaraph Converted" << endl;
	}
};

class HyperLink : public DocumentPart
{
public:
	void Print()
	{
		std::cout << "HyperLink Print" << endl;
	}
	void Save()
	{
		std::cout << "HyperLink Save" << endl;
	}
	void Convert(IDocumentConverter *coverter)
	{
		std::cout << "HyperLink Converter" << endl;
		if (nullptr != coverter)
			coverter->Convert(this);
	}
	void ConvertDoc()
	{
		std::cout << "Hyperlink Converted" << endl;
	}
};

class Header : public DocumentPart
{
public:
	void Print()
	{
		std::cout << "Header Print" << endl;
	}
	void Save()
	{
		std::cout << "Header Save" << endl;
	}
	void Convert(IDocumentConverter *coverter)
	{
		std::cout << "Header Converter" << endl;
		if (nullptr != coverter)
			coverter->Convert(this);
	}
	void ConvertDoc()
	{
		std::cout << "Header Converted" << endl;
	}
};


class PdfConverter : public IDocumentConverter
{
public:
	void Convert(Paragraph* para)
	{
		para->ConvertDoc();
		std::cout << "PDF Paragraph covert" << std::endl;
	}
	void Convert(HyperLink* hyper)
	{
		std::cout <<"PDF HyperLink covert" << std::endl;
		hyper->ConvertDoc();
	}
	void Convert(Header* header)
	{
		std::cout << "PDF Header covert" << std::endl;
		header->ConvertDoc();
	}

	/*void ConvertParagraph(Paragraph& para)
	{}
	void ConvertHyperLink(HyperLink& hyper)
	{}
	void ConvertHeader(Header& header)
	{}*/
};

class XDSConverter : public IDocumentConverter
{
public:
	void Convert(Paragraph* para)
	{
		std::cout << "XDS Paragraph covert" << std::endl;
		para->ConvertDoc();
	}
	void Convert(HyperLink* hyper)
	{
		std::cout << "XDS HyperLink covert" << std::endl;
		hyper->ConvertDoc();

	}
	void Convert(Header* header)
	{
		std::cout << "XDS Header covert" << std::endl;
		header->ConvertDoc();
	}
	/*void ConvertParagraph(Paragraph& para)
	{}
	void ConvertHyperLink(HyperLink& hyper)
	{}
	void ConvertHeader(Header& header)
	{}*/
};
class Document
{
	list<DocumentPart*> documentPart;
public:
	void Print()
	{
		auto iter = documentPart.begin();
		for(; iter != documentPart.end(); iter++)
		{
			(*iter)->Print();
		}
	}
	void Save()
	{
		auto iter = documentPart.begin();
		for (; iter != documentPart.end(); iter++)
		{
			(*iter)->Save();
		}
	}
	void Close()
	{
		std::cout << "Document Close\n";
	}
	void Add(DocumentPart* part)
	{
		documentPart.push_back(part);
	}

	void Convert(IDocumentConverter* converter)
	{
		auto iter = documentPart.begin();
		for (; iter != documentPart.end(); iter++)
		{
			(*iter)->Convert(converter);
		}
	}
};
int main()
{
    std::cout << "Visitor Pattern!\n";
	Document* doc = new Document();
	//Added multiple subtupes.
	doc->Add(new Header());
	doc->Add(new Paragraph());
	doc->Add(new HyperLink());

	//Convert using PDF converter.

	doc->Convert(new PdfConverter());
	delete doc;

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
